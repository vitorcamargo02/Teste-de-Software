

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
       <h2>Cadastro de fornecedores</h2> 
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>Problemas com seus dados:</strong>
                        <br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <form action="<?php echo e(url('fornecedor/novo')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <strong>Razão _Social:</strong>
                    <input placeholder="Digite a razão social" class="form-control mb-3" name="razão social" type="text" />
                    <strong>Endereço:</strong>
                    <input placeholder="Digite o endereço" class="form-control mb-3" name="endereço" type="text" />
                    <strong>Cidade:</strong>
                    <input placeholder="Digite a cidade" class="form-control mb-3" name="cidade" type="text" />
                    <strong>Estado:</strong>
                    <input placeholder="Digite o estado" class="form-control mb-3" name="estado" type="text" />
                    <strong>Cep:</strong>
                    <input placeholder="Digite o cep" class="form-control mb-3" name="cep" type="text" />

                    <div class="col">
                        <a class="btn btn-secondary" href="<?php echo e(url('/fornecedor')); ?>">Voltar</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" type="submit">Salvar</button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crud_Testes\resources\views/fornecedor/create.blade.php ENDPATH**/ ?>