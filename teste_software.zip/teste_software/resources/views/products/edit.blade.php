<x-guest-layout>
    <div class="max-w-6xl mx-auto">
        <h1 class="text-2xl font-semibold">Update Product</h1>

        <div class="mt-2">
            <a href="{{ route('products.index') }}" class="px-4 py-3 rounded bg-green-400">Back</a>
        </div>

        <form method="POST" action="{{ route('products.update', $product->id) }}">
            @csrf
            @method('PUT')

            <div class="mt-4">
                <label for="name" class="block">Name</label>
                <input id="name" class="block mt-1 w-full" type="text" name="name" value="{{ $product->name }}" />
            </div>

            <div class="mt-4">
                <label for="type" class="block">Type</label>
                <input id="type" class="block mt-1 w-full" type="text" name="type" value="{{ $product->type }}" />
            </div>

            <div class="mt-4">
                <label for="price" class="block">Price</label>
                <input id="price" class="block mt-1 w-full" type="text" name="price" value="{{ $product->price }}" />
            </div>

            <div class="flex items-center justify-end mt-4">
                <button class="px-4 py-2 rounded bg-blue-500 text-white">Update</button>
            </div>
        </form>
    </div>
</x-guest-layout>